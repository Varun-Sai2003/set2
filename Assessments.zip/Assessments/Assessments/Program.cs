﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessments
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Class1 ob = new Class1();
            //ob.fizzbuzz();
            //ob.prime();
            //ob.sumofdigits();
            //ob.revpalindrome();
            //ob.gcdlcm();

            Class2 ob2 = new Class2();
            //ob2.baba();
            //ob2.finore();
            //ob2.msawod();
            //ob2.countpairs();
            //ob2.countpairs1();
            //ob2.conseq();
            //ob2.major();
            //ob2.subset();
            //ob2.binsearch();
            //ob2.anagram();
            //ob2.palindromesubstring();
            //ob2.findmissingranges();
            //ob2.peak();
            //ob2.kthl();
            //ob2.longfix();
            //ob2.palinstr();
            //ob2.lis();
            //ob2.elemore3();
            //ob2.uniqcom();

        }
    }
}
