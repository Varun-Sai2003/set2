﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Assessments
{
    internal class Class1
    {

        public void fizzbuzz()
        {
            Console.WriteLine("Enter the number:");
            int n = int.Parse(Console.ReadLine());

            for (int i = 1; i <= n; i++)
            {
                if (i % 3 == 0 && i % 5 == 0)
                {
                    Console.WriteLine("FizzBuzz");
                }
                else if (i % 3 == 0)
                {
                    Console.WriteLine("Fizz");
                }
                else if (i % 5 == 0)
                {
                    Console.WriteLine("Buzz");
                }
                else
                {
                    Console.WriteLine(i);
                }
            }
        }

        public void prime()
        {
            Console.WriteLine("Enter the Number:");
            int n = int.Parse(Console.ReadLine());
            bool p = true;
            if (n <= 1)
            {
                p = false;
            }
            else
            {
                for (int i = 2; i <= Math.Sqrt(n); i++)
                {
                    if (n % i == 0)
                    {
                        p = false;
                        break;
                    }
                }
            }

            if (p)
            {
                Console.WriteLine($"{n} is a prime number.");
            }
            else
            {
                Console.WriteLine($"{n} is not a prime number.");
                Console.WriteLine("Factors:");
                for (int i = 1; i <= n; i++)
                {
                    if (n % i == 0)
                    {
                        Console.WriteLine(i);
                    }
                }
            }
        }


        public void sumofdigits()
        {
            Console.WriteLine("Enter the Number:");
            int n = int.Parse(Console.ReadLine());
            n = Math.Abs(n);

            if (n < 10)
            {
                Console.WriteLine($"Final single-digit result: {n}");
            }

            while (n >= 10)
            {
                int sum = 0;
                int temp = n;
                while (temp > 0)
                {
                    sum += temp % 10;
                    temp /= 10;
                }

                Console.WriteLine($"{n} : sum of digits = {sum}");
                n = sum;
            }

            Console.WriteLine($"Final single-digit result: {n}");
        }


        public void revpalindrome()
        {
            Console.WriteLine("Enter a number:");
            int n = int.Parse(Console.ReadLine());
            int r = 0;
            int temp = n;

            while (temp > 0)
            {
                int d = temp % 10;
                r = r * 10 + d;
                temp /= 10;
            }
            Console.WriteLine($"Reversed Number: {r}");

            if (n == r)
            {
                Console.WriteLine($"{n} is a palindrome.");
            }
            else
            {
                Console.WriteLine($"{n} is not a palindrome.");
            }
        }


        public void gcdlcm()
        {
            Console.WriteLine("Enter first number:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter second number:");
            int b = int.Parse(Console.ReadLine());
            int gcd = 1;
            int min = Math.Min(a, b); // (a<b)? a:b;
            for (int i = 1; i <= min; i++)
            {
                if (a % i == 0 && b % i == 0)
                {
                    gcd = i;
                }
            }
            int lcm = (a * b) / gcd;
            Console.WriteLine($"GCD: {gcd}");
            Console.WriteLine($"LCM: {lcm}");
        }

    }
}
