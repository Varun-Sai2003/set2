﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Assessments
{
    internal class Class2
    {
        public void baba()
        {
            Console.WriteLine("Enter the string :");
            string str = Console.ReadLine();

            Stack<char> st = new Stack<char>();

            bool balanced = true;

            foreach (char ch in str)
            {
                if (ch == '(' || ch == '{' || ch == '[')
                {
                    st.Push(ch);
                }
                else if (ch == ')' || ch == '}' || ch == ']')
                {
                    if (st.Count == 0)
                    {
                        balanced = false;
                        break;
                    }
                    char top = st.Pop();
                    if ((ch == ')' && top != '(') ||
                        (ch == '}' && top != '{') ||
                        (ch == ']' && top != '['))
                    {
                        balanced = false;
                        break;
                    }
                }
            }

            if (balanced && st.Count == 0)
            {
                Console.WriteLine("The string is balanced.");
            }
            else
            {
                Console.WriteLine("The string is not balanced.");
            }
        }


        public void finore()
        {
            
            Console.WriteLine("Enter a string:");
            string input = Console.ReadLine().ToLower();

            var res = input.GroupBy(c => c).Where(g => g.Count() == 1).Select(g => g.Key).FirstOrDefault();

            if (res != 0)
                Console.WriteLine(res);
            else
                Console.WriteLine("null");

        }


        public void msawod()
        {
            Console.WriteLine("Enter the first array:");
            string input1 = Console.ReadLine();
            int[] arr1 = string.IsNullOrWhiteSpace(input1) ? new int[0] : input1.Split(' ').Select(int.Parse).ToArray();

            Console.WriteLine("Enter the second array:");
            string input2 = Console.ReadLine();
            int[] arr2 = string.IsNullOrWhiteSpace(input2) ? new int[0] : input2.Split(' ').Select(int.Parse).ToArray();

            var m = arr1.Union(arr2).ToArray();
            Array.Sort(m);
            Console.WriteLine("Merged array without duplicates in sorted order:");
            foreach(var i in m)
            {
                Console.WriteLine(i+" ");
            }
        }


        public void countpairs()
        {
            Console.WriteLine("Enter the array:");
            int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            Console.WriteLine("Enter the target:");
            int target = int.Parse(Console.ReadLine());

            var pairs = arr
            .SelectMany((x, i) => arr
                .Skip(i + 1)
                .Where(y => x + y == target)
                .Select(y => (x, y)))
            .ToList();

            Console.Write($"Pairs with target {target}:");
            foreach(var p in pairs)
            {
                Console.Write($"({p.x}, {p.y}) ");
            }

            Console.WriteLine($"Total count: {pairs.Count}");
        }


        public void countpairs1()
        {
            Console.WriteLine("Enter the array:");
            int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            Console.WriteLine("Enter the target:");
            int target = int.Parse(Console.ReadLine());
            int count = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = i+ 1; j < arr.Length; j++)
                {
                    if (arr[i] + arr[j] == target)
                    {
                        count++;
                        Console.Write($"({arr[i]}, {arr[j]}) ");
                    }
                }
            }
            Console.WriteLine($"\nTotal count: {count}");
        }


        public void conseq()
        {
            Console.WriteLine("Enter the array:");
            int[] input = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            var arr = input.Distinct().ToArray();
            Array.Sort(arr);
            int l = 1;
            int stre = 1;
            int start = 1;
            int bs = 0;

            for (int i = 1; i < arr.Length; i++)
            {
                if (arr[i] == arr[i - 1] + 1)
                {
                    stre++;
                    if (stre > l)
                    {
                        l = stre;
                        bs = start;
                    }
                }
                else
                {
                    stre = 1;
                    start = i;
                }
            }

            Console.WriteLine($"The number of longest sequence is: {l}");
            for (int i = bs; i < bs + l; i++)
            {
                Console.Write($"({arr[i]} ");
            }
        }


        public void major()
        {
            Console.WriteLine("Enter the first array:");
            string input1 = Console.ReadLine();
            int[] arr1 = string.IsNullOrWhiteSpace(input1) ? new int[0] : input1.Split(' ').Select(int.Parse).ToArray();

            int n = arr1.Length;

            var res = arr1.GroupBy(x => x).Select(g => new { Value = g.Key, Count = g.Count() }).FirstOrDefault(g => g.Count > n / 2);

            try
            {

                if (res != null)
                    Console.WriteLine(res.Value);
                else
                    Console.WriteLine("null");
            }
            catch (Exception e)
            {
                Console.WriteLine("null");
            }
        }



        public void subset()
        {
            Console.WriteLine("Enter the array:");
            int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            var res = new List<List<int>> { new List<int>() };
            
            foreach (int num in arr) 
            {
                int count = res.Count;
                for (int i = 0; i < count; i++)
                {
                    var newSubset = new List<int>(res[i]) { num };
                    res.Add(newSubset);
                }
            }

            Console.WriteLine("All subsets:");
            foreach (var s in res) 
            {
                Console.Write("[" + string.Join(", ", s) + "]");
            }
        }



        public void binsearch()
        {
            Console.WriteLine("Enter the array:");
            int[] n = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            
            Console.WriteLine("Enter the target:");
            int target = int.Parse(Console.ReadLine());

            int l = 0, r = n.Length - 1;
            int i = -1; 

            while (l <= r)
            {
                int mid = (l+r) / 2;

                if (n[mid] == target)
                {
                    i = mid;
                    break;
                }

             
                if (n[l] <= n[mid])
                {
                    if (target >= n[l] && target < n[mid])
                    {
                        r = mid - 1; 
                    }
                    else
                    {
                        l = mid + 1;
                    }
                }
                else
                {
                    if (target > n[mid] && target <= n[r])
                    {
                        l = mid + 1;  
                    }
                    else
                    {
                        r = mid - 1; 
                    }
                }
            }

            Console.WriteLine("Target found at index: " + i);
        }



        public void freqsort()
        {
            Console.WriteLine("Enter the array:");
            int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            var sorted = arr.GroupBy(x => x).OrderByDescending(g => g.Count()).SelectMany(g => g);                               

            Console.WriteLine("Sorted by frequency:");
            Console.WriteLine(string.Join(" ", sorted));
        }



        public void anagram()
        {
            Console.WriteLine("Enter words:");
            string[] words = Console.ReadLine().Split(' ');

            var groups = words.GroupBy(w => new string(w.ToLower().OrderBy(c => c).ToArray())).ToList();

            Console.WriteLine("Grouped anagrams:");
            foreach (var group in groups)
            {
                Console.WriteLine("[" + string.Join(", ", group) + "]");
            }
        }



        public void palindromesubstring()
        {
            Console.WriteLine("Enter the string:");
            string s = Console.ReadLine();

            if (string.IsNullOrEmpty(s))
            {
                Console.WriteLine("");
                return;
            }

            int start = 0, maxLen = 1;

            for (int i = 0; i < s.Length; i++)
            {
                int l = i, r = i;
                while (l >= 0 && r < s.Length && s[l] == s[r])
                {
                    if (r - l + 1 > maxLen)
                    {
                        start = l;
                        maxLen = r - l + 1;
                    }
                    l--;
                    r++;
                }

                l = i; r = i + 1;
                while (l >= 0 && r < s.Length && s[l] == s[r])
                {
                    if (r - l + 1 > maxLen)
                    {
                        start = l;
                        maxLen = r - l + 1;
                    }
                    l--;
                    r++;
                }
            }

            string res = s.Substring(start, maxLen);
            Console.WriteLine("Longest Palindromic Substring: " + res);
        }


        public void finddup()
        {
             Console.WriteLine("Enter the array:");
            int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            //var dup = arr.Distinct().Where(g => arr.Count(n => n==g)>1).ToList();
            var dup = arr.GroupBy(x => x).Where(g => g.Count() > 1).Select(g => g.Key).ToList();

            Console.WriteLine("Duplicates: " + string.Join(", ", dup));
        }


        public void findmissingranges()
        {
            Console.WriteLine("Enter numbers :");
            int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            Console.WriteLine("Enter lower bound:");
            int lower = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter upper bound:");
            int upper = int.Parse(Console.ReadLine());

            HashSet<int> set = new HashSet<int>(arr);

            Console.WriteLine("Missing numbers:");
            for (int i = lower; i <= upper; i++)
            {
                if (!set.Contains(i))
                    Console.Write(i + " ");
            }
        }


        public void peak()
        {
            Console.WriteLine("Enter numbers :");
            int[] n = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            int left = 0, right = n.Length - 1;

            while (left < right)
            {
                int mid = (left + right) / 2;

                if (n[mid] < n[mid + 1])
                {
                    left = mid + 1;
                }
                else
                {
                    right = mid;
                }
            }

            Console.WriteLine("Peak element index: " + left);
        }

        public void kthl()
        {
            Console.WriteLine("Enter numbers :");
            int[] n = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            Console.WriteLine("Enter k:");
            int k = int.Parse(Console.ReadLine());

            Array.Sort(n);                  
            //Array.Reverse(n);             
            int res = n[n.Length - k];        

            Console.WriteLine("Kth largest element: " + res);
        }


        public void longfix()
        {
            Console.WriteLine("Enter the words:");
            string[] s = Console.ReadLine().Split(' ').ToArray();

            string prefix = new string(s.First().TakeWhile((c, a) => s.All(x => a < x.Length && x[a] == c)).ToArray());

            Console.WriteLine("Longest Common Prefix: " + prefix);
        }


        public void palinstr()
        {
            Console.WriteLine("Enter the string");
            string s = Console.ReadLine();

            int count = 0;
            for (int center = 0; center < 2 * s.Length - 1; center++)
            {
                int left = center / 2;
                int right = left + center % 2;

                while (left >= 0 && right < s.Length && s[left] == s[right])
                {
                    count++;
                    left--;
                    right++;
                }
            }

            Console.WriteLine("Count of Palindromic Substrings: " + count);
        }


        public void lis()
        {
            Console.WriteLine("Enter the number");
            int[] nums = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            int n = nums.Length;
            int[] dp = new int[n];
            int maxLen = 1;

            for (int i = 0; i < n; i++)
            {
                dp[i] = 1;
                for (int j = 0; j < i; j++)
                {
                    if (nums[j] < nums[i])
                    {
                        dp[i] = Math.Max(dp[i], dp[j] + 1);
                    }
                }
                maxLen = Math.Max(maxLen, dp[i]);
            }

            Console.WriteLine("Length of LIS: " + maxLen);
        }


        public void elemore3()
        {
            Console.WriteLine("Enter the numbers:");
            int[] nums = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            int n = nums.Length;

   
            Dictionary<int, int> freq = new Dictionary<int, int>();
            for (int i = 0; i < n; i++)
            {
                if (!freq.ContainsKey(nums[i]))
                    freq[nums[i]] = 0;
                freq[nums[i]]++;
            }

            Console.WriteLine("Elements appearing more than n/3 times:");
            foreach (var kvp in freq)
            {
                if (kvp.Value > n / 3)
                {
                    Console.Write(kvp.Key+" ");
                }
            }
        }


        public void uniqcom()
        {
            Console.WriteLine("Enter the array:");
            int[] arr = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);

            Console.WriteLine("Enter the target:");
            int target = int.Parse(Console.ReadLine());

            int count = 0;

            // Triple nested loops for triplets
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = i + 1; j < arr.Length; j++)
                {
                    for (int k = j + 1; k < arr.Length; k++)
                    {
                        if (arr[i] + arr[j] + arr[k] == target)
                        {
                            count++;
                            Console.Write($"({arr[i]}, {arr[j]}, {arr[k]}) ");
                        }
                    }
                }
            }

            Console.WriteLine($"\nTotal count: {count}");
        }

    }
}
